
package aula_03_socket_multicliente.dao;

import aula_03_socket_multicliente.tools.FactoryDatabase;
import aula_03_sockets_multicliente.Mensagem;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ChatDAO {
    
    
  public void GravarMSG(Mensagem Dados) {
    try {
        Connection c = FactoryDatabase.obterConexao();
        String sql = "INSERT INTO redes.chat(nome, texto, destino) VALUES (?, ?, ?)";
        PreparedStatement insercao = c.prepareStatement(sql);
        insercao.setString(1, Dados.getNome());
        insercao.setString(2, Dados.getTexto());
        insercao.setString(3, Dados.getDestinado());
        
        insercao.executeUpdate();
        
        c.close();
    } catch (SQLException ex) {
        ex.printStackTrace();
    }
}

    
    
   public ArrayList<Mensagem> MensagensComunidade() {
    ArrayList<Mensagem> mensagens = new ArrayList<>();
    try {
        Connection c = FactoryDatabase.obterConexao();
        String sql = "SELECT nome, texto, destino FROM redes.chat";
        PreparedStatement Result = c.prepareStatement(sql);

        ResultSet resultado = Result.executeQuery();

        while (resultado.next()) {
            Mensagem atual = new Mensagem();

            atual.setNome(resultado.getString("nome"));
            atual.setTexto(resultado.getString("texto"));
            atual.setDestinado(resultado.getString("destino"));

            // Verifica se o destino da mensagem é "Todos"
            if (atual.getDestinado().equalsIgnoreCase("Todos")) {
                
                mensagens.add(atual);
            }
            if(atual.getDestinado()== null){
                System.out.println("destino nulo");
            }
        }
        c.close();
    } catch (SQLException ex) {
        System.out.println("Ocorreu um erro ao buscar as mensagens da comunidade: " + ex.getMessage());
    }

    return mensagens;
}
   
    public ArrayList<Mensagem> MensagensPrivadas(String  destinatario, String remetente) {
        ArrayList<Mensagem> mensagensPrivadas = new ArrayList<>();

        try {
            Connection c = FactoryDatabase.obterConexao();
            String sql = "SELECT nome, texto, destino FROM redes.chat";
            PreparedStatement Result = c.prepareStatement(sql);

            ResultSet resultado = Result.executeQuery();

            while (resultado.next()) {
                Mensagem atual = new Mensagem();

                atual.setNome(resultado.getString("nome"));
                atual.setTexto(resultado.getString("texto"));
                atual.setDestinado(resultado.getString("destino"));

                // Verifica se o destino da mensagem é "Todos"
                if (atual.getDestinado().equalsIgnoreCase(destinatario)
                    && atual.getNome().equalsIgnoreCase(remetente)
                        || atual.getNome().equalsIgnoreCase(destinatario)
                        && atual.getDestinado().equalsIgnoreCase(remetente)) {
                    mensagensPrivadas.add(atual);
                }
            }
            c.close();
        } catch (SQLException ex) {
            System.out.println("Ocorreu um erro ao buscar as mensagens da comunidade: " + ex.getMessage());
        }

        return mensagensPrivadas;
    }

}
