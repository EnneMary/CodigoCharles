/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_03_socket_multicliente.control;

import aula_03_socket_multicliente.dao.UsuarioDAO;
import java.util.ArrayList;

/**
 *
 * @author 0068961
 */
public class UsuarioControl {
    
    private UsuarioDAO dao;

    public UsuarioControl() {
        this.dao = new UsuarioDAO();
    }
    
    public boolean CadastraUsuario(String nome, String senha){
        return this.dao.CadastraUsuario(nome, senha);
    }
    
    public boolean AtualizarEstado(String nome){
        return this.dao.atualizarEstadoUsuarioOn(nome);
    }
    
    public boolean VerificaEmail(String email){
        return dao.verificaEmail(email);
    }
    public boolean Verificalogin (String email, String senha){
        return dao.verificaLoginUsuario(email, senha);
    }
    
    public ArrayList<String> ListaUsuario(String nomeusuario){
        return this.dao.ListaUsuario(nomeusuario);
    }
    
    public boolean CadastraMensagem(String msg, String dest, String remet){
        return this.dao.CadastraMensagem(msg, dest, remet);
    }
    
    public boolean DesconectaUsuario(String nome){
        if (this.dao.atualizarEstadoUsuario(nome) == true){
        System.out.println("desconectado com sucesso!!");
    }
        else{
            System.out.println("Erro");     
    }
        return this.dao.atualizarEstadoUsuario(nome);
    }
    
    public ArrayList<String> ListaALL(){
        return this.dao.ReceberTodas();
    }
    
    public ArrayList<String> ListaMSGUser(String nome){
        return this.dao.ReceberMSGUser(nome);
    }
    
     public ArrayList<String> USerONLista() {
        return this.dao.usuariosNaLista();
    }
}
