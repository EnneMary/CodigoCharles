/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula_03_socket_multicliente.dao;

import aula_03_socket_multicliente.tools.FactoryDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 0068961
 */
public class UsuarioDAO {
    
    private Connection ConexaoBD;
    
    public boolean CadastraUsuario(String nome, String senha){
         try {
            Connection c = FactoryDatabase.obterConexao();
        
       String sql = "INSERT INTO redes.usuario(nome, senha, estado) "
                    + " VALUES (?,?,?);";
            PreparedStatement insercao = c.prepareStatement(sql);
            insercao.setString(1, nome);
            insercao.setString(2, senha);
            insercao.setInt(3, 1);
            insercao.execute();
            return true;
        } catch (SQLException ex){
            System.err.println("Erro ao cadastrar usuario");
            ex.printStackTrace();
            return false;
        }
    }
   public ArrayList<String> ListaUsuario(String nomeusuario) {
    ArrayList<String> listaUsers = new ArrayList<>();

    try {
        Connection c = FactoryDatabase.obterConexao();
        String sql = "SELECT nome FROM redes.usuario WHERE estado = 1 AND nome <> ? ORDER BY nome ASC;";

        try (PreparedStatement trans = c.prepareStatement(sql)) {
            trans.setString(1, nomeusuario);
            ResultSet resultadoBD = trans.executeQuery();

            while (resultadoBD.next()) {
                String nome = resultadoBD.getString("nome");
                listaUsers.add(nome);
            }
        }

        return listaUsers;

    } catch (SQLException ex) {
        System.err.println("Erro ao listar usuários online");
        ex.printStackTrace();
        return null;
    }
}

    public boolean verificaEmail(String nome) {
        try {
            Connection c = FactoryDatabase.obterConexao();
            String sql = "SELECT * FROM redes.usuario WHERE nome = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, nome);
            ResultSet resultado = consulta.executeQuery();
            c.close();
            if (resultado.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    public boolean verificaLoginUsuario(String email, String senha) {
        try {
            Connection c = FactoryDatabase.obterConexao();
            String sql = "SELECT * FROM redes.usuario WHERE nome = ? AND senha = ?";
            PreparedStatement consulta = c.prepareStatement(sql);
            consulta.setString(1, email);
            consulta.setString(2, senha);
            ResultSet resultado = consulta.executeQuery();

            c.close();
            if (resultado.next()) {
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    public boolean CadastraMensagem(String msg, String dest, String remetente){
        String sql = "INSERT INTO redes.mensagem (texto, destinatario, remetente) VALUES (?,?,?);";
        
        try(PreparedStatement trans = this.ConexaoBD.prepareStatement(sql)){
            trans.setString(1, msg);
            trans.setString(2, dest);
            trans.setString(3, remetente);
            trans.execute();
            return true;
        } catch (SQLException ex){
            ex.printStackTrace();
            return false;
        }
    }
    
    public boolean atualizarEstadoUsuario(String nome) {

        try {
            Connection c = FactoryDatabase.obterConexao();

            // A consulta SQL para atualização do estado
            String sql = "UPDATE redes.usuario SET estado = 0 WHERE nome = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            // Configurando os parâmetros para a atualização
            atualizacao.setString(1, nome);
            

            // Executando a atualização
            int linhasAfetadas = atualizacao.executeUpdate();

            // Verificando se a atualização foi bem-sucedida
            if (linhasAfetadas > 0) {
                // Se a atualização deu certo, retorna true

                return true;
            }

            // Fechando a conexão
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }

        
    public boolean atualizarEstadoUsuarioOn(String nome) {

        try {
            Connection c = FactoryDatabase.obterConexao();

            // A consulta SQL para atualização do estado
            String sql = "UPDATE redes.usuario SET estado = 1 WHERE nome = ?";
            PreparedStatement atualizacao = c.prepareStatement(sql);

            // Configurando os parâmetros para a atualização
            atualizacao.setString(1, nome);
            

            // Executando a atualização
            int linhasAfetadas = atualizacao.executeUpdate();

            // Verificando se a atualização foi bem-sucedida
            if (linhasAfetadas > 0) {
                // Se a atualização deu certo, retorna true

                return true;
            }

            // Fechando a conexão
            c.close();
        } catch (SQLException ex) {
            Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
    
    public ArrayList<String> ReceberTodas(){
            ArrayList<String> mensagensALL = new ArrayList<>();
            String sql = "SELECT * FROM redes.mensagem WHERE destinatario = 'all'";
            try(PreparedStatement trans = this.ConexaoBD.prepareStatement(sql)){
                ResultSet resultadoBD = trans.executeQuery();
            
            while(resultadoBD.next()){
                String mens = resultadoBD.getString("texto");
                String remetente = resultadoBD.getString("remetente");
                String result = mens.concat(" - " + remetente + " |");
                if(mensagensALL.contains(result)){
                    
                } else {
                mensagensALL.add(result);
                }
            }
            return mensagensALL;
            
        } catch (SQLException ex){
            System.err.println("Erro ao listar mensagens");
            ex.printStackTrace();
            return null;
        }
    }
    
    public ArrayList<String> ReceberMSGUser(String nome){
            ArrayList<String> mensagensALL = new ArrayList<>();
            String sql = "SELECT * FROM redes.mensagem WHERE destinatario = '" + nome + "';";
            try(PreparedStatement trans = this.ConexaoBD.prepareStatement(sql)){
                ResultSet resultadoBD = trans.executeQuery();
            
            while(resultadoBD.next()){
                String mens = resultadoBD.getString("texto");
                String remetente = resultadoBD.getString("remetente");
                String result = "REMETENTE:  " + remetente.concat(" - MENSAGEM:  " + mens + " - DESTINATARIO:  " + nome + " |");
                if(mensagensALL.contains(result)){
                    
                } else {
                mensagensALL.add(result);
                }
            }
            return mensagensALL;
            
        } catch (SQLException ex){
            System.err.println("Erro ao listar mensagens");
            ex.printStackTrace();
            return null;
        }
    }
        
       public ArrayList<String> usuariosNaLista() {
    ArrayList<String> remetentes = new ArrayList<>();

    try {
        Connection c = FactoryDatabase.obterConexao();
        String sql = "SELECT nome FROM CYP.usuario"; // Corrigindo a consulta SQL
        PreparedStatement consulta = c.prepareStatement(sql);

        consulta.setInt(1, 1); // Definindo o valor para o parâmetro tag
        consulta.setInt(2, 1); // Definindo o valor para o parâmetro estado

        ResultSet resultado = consulta.executeQuery();

        while (resultado.next()) {
            String atual = resultado.getString("nome");
            remetentes.add(atual);
        }

        // Fechando recursos (importante para evitar vazamentos de recursos)
        resultado.close();
        consulta.close();
        c.close();

    } catch (SQLException e) {
        // Lidar com exceções, por exemplo, imprimir mensagem ou lançar uma nova exceção
        e.printStackTrace();
    }

    return remetentes;
}

}

