/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package aula_03_sockets_multicliente.view;

import aula_03_sockets_multicliente.Cliente;
import aula_03_sockets_multicliente.Mensagem;
import aula_03_sockets_multicliente.Tarefas;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

/**
 *
 * @author 0068957
 */
public class FrameChatPrivado extends javax.swing.JFrame {

    private Cliente usuario;
    private static String remetente;
    private static String Destinatario;
    public FrameChatPrivado() {
        initComponents();
        VerificaFechamento();
    }
    
    public FrameChatPrivado(String NomeUsuario, String nomedestino){
        initComponents();
        DestinoTxt.setText(nomedestino);
        remetente = NomeUsuario;
        Destinatario = nomedestino;
        this.setTitle(nomedestino);
        PlanoMSGeral();
        VerificaFechamento();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        DestinoTxt = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Lprivado = new javax.swing.JList<>();
        btnSair = new javax.swing.JButton();
        TextEntrada = new javax.swing.JTextField();
        btnEnviar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        fotofundo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        DestinoTxt.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        DestinoTxt.setText("Nome");
        jPanel1.add(DestinoTxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, 250, 20));

        Lprivado.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jScrollPane1.setViewportView(Lprivado);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 100, 730, 530));

        btnSair.setBackground(new java.awt.Color(255, 51, 51));
        btnSair.setText("X");
        btnSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSairActionPerformed(evt);
            }
        });
        jPanel1.add(btnSair, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 10, 60, -1));
        jPanel1.add(TextEntrada, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 680, 650, 30));

        btnEnviar.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        btnEnviar.setText(">");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnviar, new org.netbeans.lib.awtextra.AbsoluteConstraints(790, 670, 89, 40));

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jButton1.setText("<");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 50, -1));

        fotofundo.setIcon(new javax.swing.ImageIcon("C:\\Users\\0068957\\Downloads\\aula_03_socket_multicliente\\aula_03_socket_multicliente\\src\\main\\java\\imagens\\5.png")); // NOI18N
        fotofundo.setText("jLabel1");
        jPanel1.add(fotofundo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1001, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
       String txt = TextEntrada.getText();
       
        try {
            if (Destinatario!=null && remetente != null){
            usuario = new Cliente("127.0.0.1", 15500);    
            Mensagem novaMensagem = new Mensagem(remetente, txt, Destinatario);
            Tarefas Novatarefa = new Tarefas("Enviar", novaMensagem);
            usuario.enviar_mensagem(Novatarefa);
            usuario.receber_mensagem();
            btnEnviar.setText("");
            }
            else{
                JOptionPane.showMessageDialog(this, "Ops, Ocorreu um erro!!", "Destino nulo", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_btnEnviarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        FrameApp redirecionar = new FrameApp(remetente);
        redirecionar.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void btnSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSairActionPerformed
        try {
            usuario = new Cliente("127.0.0.1", 15500);
            Tarefas novaTarefa = new Tarefas("sair", remetente);
            usuario.enviar_mensagem(novaTarefa);
            System.out.println(usuario.receber_mensagem());
            usuario.finalizar();
            dispose();
        } catch (Exception ex) {
            Logger.getLogger(FrameApp.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnSairActionPerformed
   
    public void PlanoMSGeral() {

        SwingWorker AtualizaOnline = new SwingWorker() {
            @Override
            protected Object doInBackground() throws Exception {
                while (true) {  
                    usuario = new Cliente("127.0.0.1", 15500);
                    Tarefas novaTarefas = new Tarefas("Privado", remetente, Destinatario);
                    usuario.enviar_mensagem(novaTarefas);                
                    List<Mensagem> lista = (List<Mensagem>) usuario.receber_mensagem();
                    System.out.println("Receber mensagens");
                    DefaultListModel MsgList = new DefaultListModel();
                    MsgList.addAll(lista);
                    Lprivado.setModel(MsgList);
                    Thread.sleep(1000);
                   
                    
                }
            }

        };
        AtualizaOnline.execute();
    }  
    private void VerificaFechamento() {
        //Aqui ele verifica se o usuario clicou para sair do programa
        this.addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                try {
                    usuario = new Cliente("127.0.0.1", 15500);
                    usuario.enviar_mensagem(new Tarefas("sair", remetente));
                    usuario.receber_mensagem();
                } catch (Exception ex) {
                    Logger.getLogger(FrameChatPrivado.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameChatPrivado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameChatPrivado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameChatPrivado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameChatPrivado.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameChatPrivado().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel DestinoTxt;
    private javax.swing.JList<Mensagem> Lprivado;
    private javax.swing.JTextField TextEntrada;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JButton btnSair;
    private javax.swing.JLabel fotofundo;
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
