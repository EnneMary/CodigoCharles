package aula_03_sockets_multicliente;

import aula_03_socket_multicliente.control.ChatControl;
import aula_03_socket_multicliente.control.UsuarioControl;
import java.net.Socket;
import java.util.ArrayList;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TrataCliente implements Runnable {

    private Socket soquete_cliente;
    private ObjectOutputStream saida;
    private ObjectInputStream entrada;
    private ArrayList<Mensagem> mensagens;
    private ArrayList<String> usuarios;
    private UsuarioControl usuarioControl;
    private ChatControl chatcontrol;
    private Mensagem NovoChat;

    public TrataCliente(Socket soquete_cliente, ArrayList<Mensagem> mensagens, ArrayList<String> usuarios) throws Exception {
        super();
        this.soquete_cliente = soquete_cliente;
        this.saida = new ObjectOutputStream(this.soquete_cliente.getOutputStream());
        this.entrada = new ObjectInputStream(this.soquete_cliente.getInputStream());
        this.mensagens = mensagens;
        this.usuarios = usuarios;
        this.usuarioControl = new UsuarioControl();
        chatcontrol = new ChatControl();
   
    }

    public void enviar_mensagem(Object mensagem) throws Exception {
        this.saida.writeObject(mensagem);
        this.saida.flush();
    }

    public Tarefas receber_mensagem() throws Exception {
        return (Tarefas) this.entrada.readObject();
    }

    public void finalizar() throws IOException {
        this.soquete_cliente.close();
    }

    @Override
    public void run() {
        String user = soquete_cliente.getInetAddress().getHostAddress();
        System.out.println(user);
        Tarefas request;
        try {       
            
            do {

                request = (Tarefas) receber_mensagem();
                
                if(request.getPedido().equals("banco")){           
                enviar_mensagem(usuarioControl.ListaUsuario(request.getNomeUsuario()));
                }
                
                if(request.getPedido().equals("Gerais")){   
                    enviar_mensagem(chatcontrol.Mensagens());  
               
                }
                
                if(request.getPedido().equals("Cadastrar")){
                    usuarioControl.CadastraUsuario(request.getNomeUsuario(), request.getSenha());
                    enviar_mensagem("conectado");
                }
              
                if(request.getPedido().equals("to on!")){
                    usuarioControl.AtualizarEstado(request.getNomeUsuario());
                    enviar_mensagem("Tá on");
                }
                
                if(request.getPedido().equals("Privado")){   
                    String Destinatario = request.getSenha();
                    String remetente = request.getNomeUsuario();
                    enviar_mensagem(chatcontrol.MensagensPrivadas(Destinatario, remetente));
                }
                
                if (request.getPedido().equals("Enviar")) {
                    chatcontrol.GravarMsg(request.getMensagem());
                    enviar_mensagem("Gravado!!");
                }

                if(request.getPedido().equals("sair")){
                    String nome = request.getNomeUsuario();
                    usuarioControl.DesconectaUsuario(nome);    
                    enviar_mensagem("desconectado");
                   
                    
                 
                }
                
            } while (!request.getPedido().equals("F"));
        
           
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
