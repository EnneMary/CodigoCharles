
package aula_03_sockets_multicliente;

import java.io.Serializable;

public class Tarefas implements Serializable {
    
    private String Pedido;
    private String NomeUsuario;
    private String Senha;
    private Mensagem mensagem;
    private String Destino;

    public Tarefas(String Pedido, String NomeUsuario, String Senha) {
        this.Pedido = Pedido;
        this.NomeUsuario = NomeUsuario;
        this.Senha = Senha;
  
    }

    public Tarefas(String Pedido, Mensagem mensagem) {
        this.Pedido = Pedido;
        this.mensagem = mensagem;
    }

    public Tarefas(String Pedido) {
        this.Pedido = Pedido;
    }

    public Tarefas(String Pedido, String NomeUsuario) {
        this.Pedido = Pedido;
        this.NomeUsuario = NomeUsuario;
    }
    
    
    
    public String getPedido() {
        return Pedido;
    }

    public void setPedido(String Pedido) {
        this.Pedido = Pedido;
    }

    public String getNomeUsuario() {
        return NomeUsuario;
    }

    public void setNomeUsuario(String NomeUsuario) {
        this.NomeUsuario = NomeUsuario;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String Senha) {
        this.Senha = Senha;
    }

    public Mensagem getMensagem() {
        return mensagem;
    }

    public void setMensagem(Mensagem mensagem) {
        this.mensagem = mensagem;
    }

    @Override
    public String toString() {
        return "Tarefas{" + "Pedido=" + Pedido + ", NomeUsuario=" + NomeUsuario + ", Senha=" + Senha + ", mensagem=" + mensagem + ", Destino=" + Destino + '}';
    }

    
}
