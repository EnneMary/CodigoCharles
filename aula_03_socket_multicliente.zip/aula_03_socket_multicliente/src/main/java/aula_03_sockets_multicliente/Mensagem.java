package aula_03_sockets_multicliente;

import java.io.Serializable;

public class Mensagem implements Serializable {
	private String nome;
	private String texto;
        private String Destinado;
	
	public Mensagem(String nome, String texto, String destinado) {
		super();
		this.nome = nome;
		this.texto = texto;
                this.Destinado = destinado;
	}

    public Mensagem() {
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTexto() {
		return texto;
	}

    public String getDestinado() {
        return Destinado;
    }

    public void setDestinado(String Destinado) {
        this.Destinado = Destinado;
    }

	public void setTexto(String texto) {
		this.texto = texto;
	}

	@Override
	public String toString() {
		return  nome + ": " + texto;
	}
	
}