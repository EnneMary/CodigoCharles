package aula_03_socket_multicliente.control;

import aula_03_socket_multicliente.dao.ChatDAO;
import aula_03_sockets_multicliente.Mensagem;
import java.io.Serializable;
import java.util.ArrayList;


public class ChatControl {
    ChatDAO ServicosChat = new ChatDAO();
    
  public ArrayList<Mensagem> Mensagens(){
        return this.ServicosChat.MensagensComunidade();
    }
  
  public void GravarMsg(Mensagem dados){
    this.ServicosChat.GravarMSG(dados);
}
  
  public ArrayList<Mensagem> MensagensPrivadas(String destino, String remete){
        return this.ServicosChat.MensagensPrivadas(destino, remete);
    }
}